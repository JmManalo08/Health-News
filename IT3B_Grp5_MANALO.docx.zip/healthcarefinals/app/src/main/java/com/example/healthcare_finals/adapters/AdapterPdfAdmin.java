package com.example.healthcare_finals.adapters;


import static com.example.healthcare_finals.Constants.MAX_BYTES_PDF;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthcare_finals.MyApplication;
import com.example.healthcare_finals.PdfDetailActivity;
import com.example.healthcare_finals.PdfEditActivity;
import com.example.healthcare_finals.databinding.RowPdfAdminBinding;
import com.example.healthcare_finals.filters.FilterPdfAdmin;
import com.example.healthcare_finals.models.ModelPdf;
import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.listener.OnErrorListener;
import com.github.barteksc.pdfviewer.listener.OnLoadCompleteListener;
import com.github.barteksc.pdfviewer.listener.OnPageErrorListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class AdapterPdfAdmin  extends RecyclerView.Adapter<AdapterPdfAdmin.HolderPdfAdmin> implements Filterable {

    //context
    private Context context;
    //arraylist to hold list of data of type ModelPdf
    public ArrayList<ModelPdf>pdfArrayList,filerList;


    //view binding row_pdf.admin.xml
    private RowPdfAdminBinding binding;


    private FilterPdfAdmin filter;


    private static final String TAG = "PDF_ADAPTER_TAG";

    private ProgressDialog progressDialog;



    // constructor
    public AdapterPdfAdmin(Context context, ArrayList<ModelPdf> pdfArrayList) {
        this.context = context;
        this.pdfArrayList = pdfArrayList;
        this.filerList = pdfArrayList;

        //init progress dialog
        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Please Wait");
        progressDialog.setCanceledOnTouchOutside(false);

    }

    @NonNull
    @Override
    public HolderPdfAdmin onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // bind layout using view binding
        binding = RowPdfAdminBinding.inflate(LayoutInflater.from(context), parent, false);

        return new HolderPdfAdmin(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull HolderPdfAdmin holder, int position) {
        //get data set data handle click etc.

        //get data
        ModelPdf model = pdfArrayList.get(position);
        String pdfId = model.getId();
        String categoryId = model.getCategoryId();
        String title = model.getTitle();
        String description = model.getDescription();
        String pdfUrl = model.getUrl();
        long timestamp = model.getTimestamp();

        //we need to convert timestamp to //dd/MM/yyyy
        String formattedDate = MyApplication.formatTimeStamp(timestamp);

        //set data
        holder.titleTv.setText(title);
        holder.descptionTv.setText(description);
        holder.dateTv.setText(formattedDate);


        //load further detailes like category ,pdf from url size in seperate function
        MyApplication.loadCategory(
                ""+categoryId,
                holder.categoryTv
        );
        MyApplication.loadPdfFromUrlSinglePage(
                ""+pdfUrl,
                ""+title,
                holder.pdfView,
                holder.progressBar,
                null
                );
        MyApplication.loadPdfsize(
                ""+pdfUrl,
                ""+title,
                holder.sizeTv
                );

        //handle click show dialog with option 1) edit 2) delete

        holder.moreBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moreOptionsDialog(model, holder);

            }
        });

        //handle click, open pdf details page, pass pdf/book id to get detail of it
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, PdfDetailActivity.class);
                intent.putExtra("bookId", pdfId);
                context.startActivity(intent);
            }
        });
        

    }

    private void moreOptionsDialog(ModelPdf model, HolderPdfAdmin holder) {

        String bookId = model.getId();
        String bookUrl = model.getUrl();
        String bookTitle = model.getTitle();

        //option to show in dialog
        String[] options = {"Edit", "Delete"};


        //alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Choose Option")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //handle dialog option click
                        if (i==0){
                            //edit clicked
                            // edit clicked, Open new activity to edit the book info
                            Intent intent = new Intent(context, PdfEditActivity.class);
                            intent.putExtra("bookId",bookId);
                            context.startActivity(intent);



                        }
                        else if (i==1){
                            //Delete Clicked
                            MyApplication.deletebook(context,
                                    ""+bookId,
                                    ""+bookUrl,
                                    ""+bookTitle
                            );
                           // deletebook(model,holder);
                        }

                    }
                })
                .show();
    }









    @Override
    public int getItemCount() {

        return pdfArrayList.size();// return number of records | list size
    }

    @Override
    public Filter getFilter() {
        if (filter == null){
            filter = new  FilterPdfAdmin(filerList, this);
        }
        return filter;
    }


    /*View HolderPdfAdmin class for row_pdf_admin.xml */

    class HolderPdfAdmin extends RecyclerView.ViewHolder{

        //ui view of row_pdf_admin.xml
        PDFView pdfView;
        ProgressBar progressBar;
        TextView titleTv,descptionTv,categoryTv,sizeTv,dateTv;
        ImageButton moreBtn;

        public HolderPdfAdmin(@NonNull View itemView) {
            super(itemView);

            //init ui view
            pdfView = binding.pdfView;
            progressBar = binding.progressBar;
            titleTv = binding.titleTv;
            descptionTv = binding.descptionTv;
            categoryTv = binding.categoryTv;
            sizeTv = binding.sizeTv;
            dateTv = binding.dateTv;
            moreBtn = binding.moreBtn;

        }
    }


}
