package com.example.healthcare_finals.filters;

import android.widget.Filter;

import com.example.healthcare_finals.adapters.AdapterCategory;
import com.example.healthcare_finals.adapters.AdapterPdfAdmin;
import com.example.healthcare_finals.models.ModelCategory;
import com.example.healthcare_finals.models.ModelPdf;

import java.util.ArrayList;

public class FilterPdfAdmin extends Filter{

    //arraylist in which want to search
    ArrayList<ModelPdf> filterlist;
    //adapter in which filter need to be implemented
    AdapterPdfAdmin adapterPdfAdmin;

    //constructor
    public FilterPdfAdmin(ArrayList<ModelPdf> filterlist, AdapterPdfAdmin adapterPdfAdmin){
        this.filterlist = filterlist;
        this.adapterPdfAdmin = adapterPdfAdmin;

    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();
        if (constraint != null && constraint.length()>0){
            //change to  upper case or lowercase sensitivity
            constraint = constraint.toString().toUpperCase();
            ArrayList<ModelPdf> filteredModels = new ArrayList<>();
          for (int i=0; i<filterlist.size();i++){
              //validate
              if (filterlist.get(i).getTitle().toUpperCase().contains(constraint)){
                  //add to filtered list
                  filteredModels.add(filterlist.get(i));

              }
          }
          results.count =filteredModels.size();
          results.values = filteredModels;

        }
        else {
            results.count= filterlist.size();
            results.values =filterlist;
        }
        return results; // dont
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        //applyfilter
        adapterPdfAdmin.pdfArrayList = (ArrayList<ModelPdf>)results.values;


        //notify changes
        adapterPdfAdmin.notifyDataSetChanged();


    }
}
