package com.example.healthcare_finals.filters;

import android.widget.Filter;

import com.example.healthcare_finals.adapters.AdapterCategory;
import com.example.healthcare_finals.adapters.AdapterPdfAdmin;
import com.example.healthcare_finals.models.ModelCategory;
import com.example.healthcare_finals.models.ModelPdf;

import java.util.ArrayList;

public class FilterCategory extends Filter{

    //arraylist in which want to search
    ArrayList<ModelCategory> filterlist;
    //adapter in which filter need to be implemented
    AdapterCategory adapterCategory;

    //constructor
    public FilterCategory (ArrayList<ModelCategory> filterlist,AdapterCategory adapterCategory){
        this.filterlist = filterlist;
        this.adapterCategory = adapterCategory;

    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();
        if (constraint != null && constraint.length()>0){
            //change to  upper case or lowercase sensitivity
            constraint = constraint.toString().toUpperCase();
            ArrayList<ModelCategory> filteredModels = new ArrayList<>();
          for (int i=0; i<filterlist.size();i++){
              //validate
              if (filterlist.get(i).getCategory().toUpperCase().contains(constraint)){
                  //add to filtered list
                  filteredModels.add(filterlist.get(i));

              }
          }
          results.count =filteredModels.size();
          results.values = filteredModels;

        }
        else {
            results.count= filterlist.size();
            results.values =filterlist;
        }
        return results; // dont
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        //applyfilter
        adapterCategory.categoryArrayList = (ArrayList<ModelCategory>)results.values;


        //notify changes
        adapterCategory.notifyDataSetChanged();


    }
}
